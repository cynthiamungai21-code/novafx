export default async function handler(req,res){
 const a=req.headers.authorization;if(!a)return res.status(401).json({error:"Missing Authorization"});
 const r=await fetch("https://api.derivws.com/trading/v1/options/accounts",{headers:{"Deriv-App-ID":34f90HIkPCdGVmJYUBCto,"Authorization":a}});
 const j=await r.json();return res.status(r.status).json(j);
}