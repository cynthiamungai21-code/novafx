export default async function handler(req,res){
 if(req.method!=="POST")return res.status(405).json({error:"Method not allowed"});
 try{
  const {code,code_verifier,redirect_uri}=req.body||{};
  const body=new URLSearchParams({grant_type:"authorization_code",client_id:34f90HIkPCdGVmJYUBCto",code,code_verifier,redirect_uri});
  const r=await fetch("https://auth.deriv.com/oauth2/token",{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body});
  const j=await r.json();return res.status(r.status).json(r.ok?j:{error:j.error_description||j.error||"Token exchange failed"});
 }catch(e){return res.status(500).json({error:e.message})}
}