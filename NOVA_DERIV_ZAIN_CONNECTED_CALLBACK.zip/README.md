# NOVA Deriv Auto Connect
Deriv OAuth client ID: 34f90HIkPCdGVmJYUBCto
Callback URL: https://zain-blush.vercel.app/callback

Register the callback URL exactly in the Deriv OAuth application, then deploy this ZIP to Vercel.
The app automatically starts OAuth once on a fresh session and also has a CONNECT DERIV retry button.
